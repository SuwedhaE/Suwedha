export class User{
    id:any;
    firstname:string;
    lastname:string;
    email:string;
}