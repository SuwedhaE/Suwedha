package Search;

import java.util.Arrays;

public class ExponentialSearch {

	public static void main(String[] args) {
		int arr[] = {00,11,22,33,44,55,66};
		int val = 11;
		int outcome=exponentialSearch(arr,arr.length,val);
		
		if(outcome<0) {
			System.out.println("Element is not present in array");
		}
		else {
			System.out.println("Element found at index: "+outcome+", Key is: "+arr[outcome]);
		}
	}

	private static int exponentialSearch(int[] arr, int length, int val) {
		if(arr[0]==val) {
			return 0;
		}
		
		int i=1; 
		
		while(i<length && arr[i]<=val) {
			i= i*2;
		}
		return Arrays.binarySearch(arr,i/2,Math.min(i, length),val);
	}
}
