package Search;

import java.util.Scanner;

public class LinearSearch {
	
public static void main(String[] args) {
        
        int  [] arr= {00,11,22,33,44,55,66};
        
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the number to  be searced");
        int SearchValue= sc.nextInt();
        
        int val = linear(arr,SearchValue);
        
        if(val==-1) {
            System.out.println("Number is  not found ");
        }
        else {
            System.out.println("Number found at index: ["+val+"] , and search  key is : "+arr[val]);
        }
        
    }
    
    private static int linear(int[] arr,int searchValue) {
        
                 
        for(int i=0; i<arr.length; i++) {
            
            if(arr[i]==searchValue) {
                return i;
            }
            
        }
        return -1;
    }


}
