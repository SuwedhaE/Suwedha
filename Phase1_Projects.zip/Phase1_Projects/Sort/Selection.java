package Sort;

public class Selection {
	
	public static void main(String[] args) {
		
		int arr[]= {12,6,8,4,10,2};
		selectionSort(arr);
		int len = arr.length;
		
	    System.out.println("The sorted elements are:");
		
		for(int i:arr) {
			System.out.print(i+ "\t");
		}
		
	}

	private static void selectionSort(int[] arr) {
		int len = arr.length;
		for(int i=0; i<len-1; i++) {
			int index = i;
			
			for(int j=i+1; j<len; j++) {
				if(arr[j]<arr[index]) {
					index = j;
				}
			}
			
			int temp = arr[index];
			arr[index]=arr[i];
			arr[i]=temp;
			
			for(int x: arr) {
				System.out.print(x + " ");
			}
			System.out.println();
		}
	}

}
